(function(){
  const navToggle = document.getElementById('navToggle');
  const mobileNav = document.getElementById('mobileNav');
  if(navToggle && mobileNav){
    navToggle.addEventListener('click', () => {
      mobileNav.classList.toggle('show');
    });
    mobileNav.querySelectorAll('a').forEach(a => a.addEventListener('click', () => {
      mobileNav.classList.remove('show');
    }));
  }

  const year = document.getElementById('year');
  if(year) year.textContent = new Date().getFullYear();

  const form = document.getElementById('leadForm');
  if(form){
    form.addEventListener('submit', () => {
      try {
        const data = Object.fromEntries(new FormData(form).entries());
        localStorage.setItem('rr_lead', JSON.stringify(data));
      } catch(e){}
    });
  }
})();
